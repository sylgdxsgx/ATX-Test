Welcome to imageio's documentation!
===================================

.. automodule:: imageio


Contents:

.. toctree::
  :maxdepth: 2
  
  sec_gettingstarted
  sec_reference
  sec_developer
