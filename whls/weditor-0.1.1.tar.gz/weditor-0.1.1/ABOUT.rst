Related Project: https://github.com/openatx/weditor
