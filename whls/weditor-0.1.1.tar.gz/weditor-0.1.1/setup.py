#!/usr/bin/env python
# coding: utf-8
#
# Licensed under MIT
#

from setuptools import setup

setup(setup_requires=['pbr'], pbr=True)
