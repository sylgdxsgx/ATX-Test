## atx uiautomator2-init standalone
该版本不用联网下载依赖

## 使用方法
使用notepad打开`设备初始化.bat` 修改其中的atx-server地址

1. 双击脚本
2. 插入安卓手机，会自动启动初始化步骤。等待控制台出现Init Success表示成功

## 更新历史
- 2018/03/30 第一版创建
