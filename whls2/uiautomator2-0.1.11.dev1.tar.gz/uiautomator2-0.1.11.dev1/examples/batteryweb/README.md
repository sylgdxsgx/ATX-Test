# batteryweb
Easy watch device battery

# Install
```bash
pip install -r requirements.txt
```

# Usage

```bash
export FLASK_APP="main.py"
export FLASK_DEBUG=1
flask run
```

Demo

![img](https://testerhome.com/uploads/photo/2017/60770b8c-555b-4e54-81f5-ed4facd87ecc.png)
