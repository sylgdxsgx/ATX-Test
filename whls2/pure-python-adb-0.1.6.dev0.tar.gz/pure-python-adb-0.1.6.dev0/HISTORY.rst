1.0.0 (2018-06-23)
------------------

* First release on PyPI.